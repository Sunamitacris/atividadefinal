const {validaIdade, senhaValidar, senhaIguais, senhaTamanho} = require ('./formu.js')

it(' se idade for maior ou igual a 18 anos',() => {
    expect (validaIdade(18)).toBe(true)
})

it(' se idade for menor que 18 anos',() => {
    expect (validaIdade(12)).toBe(false)
})

it(' se a senha for menor que  oito digitos',() => {
    expect (senhaTamanho(Ab12g4)).toBe(false)
})
it(' se a senha for maior ou igual a 8 digitos',() => {
    expect (senhaTamanho('Ab56hy@7')).toBe(true)
})
it(' senha com número',() => {
    expect (senhaValidar('7')).toBe(false)

})
it(' se senha com letra',() => {
    expect (senhaValidar('h')).toBe(false)
})
it(' se a senha tiver letra e número',() => {
    expect (senhaValidar('2j')).toBe(true)
})
it(' se a senha tiver letra minuscula',() => {
    expect (senhaValidar('s')).toBe(true)
})
it(' se a senha tiver letra maiúscula',() => {
    expect (senhaValidar('B')).toBe(true)
})
it(' se as senhas for diferentes',() => {
    expect (senhaIguais('A3', '43')).toBe(false)
})
it(' se as senhas forem iguais',() => {
    expect (senhaIguais('9n', '9n')).toBe(true)
})

